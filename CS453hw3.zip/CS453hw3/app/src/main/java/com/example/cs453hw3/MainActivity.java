package com.example.cs453hw3;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //creates class object to handle databased
        final Handler db = new Handler(getApplicationContext());
        final EditText edittext = (EditText) findViewById(R.id.editText);
        final EditText edittext2 = (EditText) findViewById(R.id.editText2);

        //button takes data and passes it to the handler.
        Button btn = (Button) findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView textview = (TextView) findViewById(R.id.textview);
                String title = edittext.getText().toString();
                String content = edittext2.getText().toString();
                if(title.isEmpty())
                {
                    Toast.makeText(MainActivity.this,"error you must enter a title",Toast.LENGTH_LONG).show();

                }
                else if(content.isEmpty())
                {
                    Toast.makeText(MainActivity.this,"error you must enter content of the flashcard",Toast.LENGTH_LONG).show();

                }
                else {
                    boolean inserted = db.insert(title, content);
                    if (inserted == true) {
                        Toast.makeText(MainActivity.this, "Insertion successful yay!", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Insertion not successful boo!", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
        //prints content of database to the screen
        Button viewBtn = (Button) findViewById(R.id.button);
        viewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView textview = (TextView) findViewById(R.id.textview);
                String result = "";
                Cursor res = db.getAllFlashCards();
                if(res.getCount() == 0)
                {
                    Toast.makeText(MainActivity.this,"error pulling from Database",Toast.LENGTH_LONG).show();
                }
                else
                {
                    if(res.moveToFirst())
                    {
                        do{
                            result += "Title: " + res.getString(1) + "\nContent: " + res.getString(2) + "\n\n";

                        }while(res.moveToNext());
                    }
                    textview.setText(result);

                }
            }
        });


    }
}
